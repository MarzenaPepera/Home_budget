package pl.rafalmiskiewicz.ADOZL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class AdozlApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdozlApplication.class, args);
    }
}
