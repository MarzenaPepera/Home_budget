package pl.rafalmiskiewicz.ADOZL.places;

import pl.rafalmiskiewicz.ADOZL.schedule.Schedule;

import java.util.List;


public interface PlacesService {

    Places findPlacesById(int id);


}
