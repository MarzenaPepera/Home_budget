package pl.rafalmiskiewicz.ADOZL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdozlApplicationTests {

    @Test
    void contextLoads() {
    }

}
